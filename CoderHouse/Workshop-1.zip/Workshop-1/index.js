class Student{
	constructor(firstName, lastName, dni, email){
		this.firstName = firstName
		this.lastName = lastName
		this.dni = dni
		this.email = email
	}

	fullName() {
		return this.firstName + ' ' + this.lastName
	}
}	
isDataAtLocalStorage()


var fName = [];
var lName = [];
var dni_ = [];
var email_ = [];
var student = []
var newStudent = [];
var studentLengthKey = 0;
var studentLength = 1; 
var localLength;

function isDataAtLocalStorage(){
	if(!localStorage.getItem("STUDENTS")){
		localStorage.setItem('STUDENTS', JSON.stringify([]))
	}

	showStudents()
	getInputValue()
}





function getInputValue(){
	document.getElementById('firstName').onblur = function() {
		fName = this.value
	};
	
	document.getElementById('lastName').onblur = function() {
		lName = this.value
	}

	document.getElementById('dni').onblur = function() {
		dni_ = this.value
	}
	document.getElementById('email').onblur = function() {
		email_ = this.value
	}

	
}

function validateInput(f_name, l_name, dni__, email__){
	var isValid;
	var data = []
	data.push(f_name, l_name, dni__, email__)
	if((data[0] && isNaN(data[0])) && 
		(data[1] && isNaN(data[1])) && 
		(data[2] && !isNaN(data[2])) && 
		(data[3] && data[3].indexOf('@') > 0)){
		isValid = true;
		//
	}else{
		
		isValid = false;
		
	}
	
	return isValid
	

}
function saveStudents(){
		if(validateInput(fName, lName, dni_, email_)){
			var students = JSON.parse(localStorage.getItem('STUDENTS'))
			var student = new Student(fName, lName, dni_, email_)
			if(students.length > 0){
				var exist = false;
				students.forEach(student_ => {

					if(student_.dni === dni_){
						exist = true;
					}
				})
				if(!exist){
					students.push(student)
					addStudent(student)
				}
			}else{
				students.push(student)
				addStudent(student)
			}
			
			
			localStorage.setItem('STUDENTS', JSON.stringify(students))
			document.getElementById('firstName').className = 'form-control is-valid'
			
		}else{
			document.getElementById('firstName').className = 'form-control is-invalid'
		}	
	}
	


function showStudents() {
	var ulStudents = document.getElementById('mainList')

	
	JSON.parse(localStorage.getItem('STUDENTS')).forEach(student => {
		addStudent(new Student(student.firstName, student.lastName, student.dni, student.email))
	})
			firstName.value = '';
			lastName.value = '';
			dni.value = '';
			email.value = '';

}

function addStudent(student){
	var ulStudents = document.getElementById('mainList')
		var liStudent = document.createElement('li')
		liStudent.innerHTML = `<h2>${student.fullName()}</h2> <p>${student.dni +' <br> '+ student.email}</p>`;
		ulStudents.appendChild(liStudent)
	
}





